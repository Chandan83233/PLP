﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Data.Entity;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer

        LoginEntities db =new LoginEntities();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }
        public ActionResult Registration()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Registration([Bind(Include = "UserId,Passcode,AccountNo,Phone,Name,Email")] CustomerDetail customer)
        {
            if (ModelState.IsValid)
            {
                db.CustomerDetails.Add(customer);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(customer);
        }
        

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(CustomerDetail objUser)
        {
            if (ModelState.IsValid)
            {
                using (LoginEntities db = new LoginEntities())
                {
                    var obj = db.CustomerDetails.Where(a => a.UserId.Equals(objUser.UserId) && a.Passcode.Equals(objUser.Passcode)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserID"] = obj.UserId.ToString();
                        Session["UserName"] = obj.Name.ToString();
                        return RedirectToAction("UserDashBoard");
                    }
                }
            }
            return View(objUser);
        }

        public ActionResult UserDashBoard()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
    }
}  
    
