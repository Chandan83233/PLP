﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
   

namespace WebApplication1.Models
{
    public class CustomerDetailMetaData
    {
        [Required(ErrorMessage ="Write User Id")]
        [RegularExpression(@"^[A-Z]{2}\d{3}[a-zA-Z0-9]{1}" , ErrorMessage ="User Id must be of 6 character With 2 UpperCase letter followed by 4 digit. " )]
        public string UserId { get; set; }

        [Required(ErrorMessage = "Enter your Password")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$", ErrorMessage = "Password must be of 8 character and must include one upprcase,one lowercase, one special character and atleast one number.")]
        public string Passcode { get; set; }

        [Required(ErrorMessage = "Write User Id")]
        [RegularExpression(@"^[0-9]\d{9}", ErrorMessage = "Account No should  should be of 10 digit")]
        public long AccountNo { get; set; }

        [RegularExpression(@"^[6-9]\d{9}", ErrorMessage = "Phone No should start with 6 to 9 and should be of 10 digit")]
        public long Phone { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [RegularExpression(@"^[A-Z][A-Za-z\s]+$", ErrorMessage = "Name should be start with Capital letter and should be alphabet only")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Should be a valid email")]
        public string Email { get; set; }
    }
}